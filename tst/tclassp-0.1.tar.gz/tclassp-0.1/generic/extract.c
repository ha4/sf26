/*
*  C Implementation: segsam
*
* Description:
*
*
* Author: Lasse Bombien <lasse@cordulo>, (C) 2007
*
* Copyright: See COPYING file that comes with this distribution
*
*/
 /* $Id: extract.c,v 1.4 2008/04/23 11:59:25 lasselasse Exp $ */

#include <tcl.h>
#include <string.h>     /* str... */
#include <errno.h>
#include <misc.h>
#include <asspfio.h>
#include <dataobj.h>
//#include <assp.h>

#include <ipds_lbl.h>
#include <asspana.h>
#include <asspmess.h>
#include <assptime.h>
#include "tclassp.h"
/*
Syntax:
  segsam [-nocomplain] infile start end outfile

Description:
  Extracts data from a file and writes it to another

Details:
  infile: any datafile readable by libassp to extract data from
  start: start extraction at given time in seconds (0 = begin of data)
  end: end extraction at given time in seconds (0 = end of data)
  outfile: write data to this file if writeable. Existing data will be
    overwritten
  if -nocomplain is specified, set invalid start / end times to
    start / end of data

Value:
  TCL_OK or TCL_ERROR on error
*/
int extract_Cmd (
  ClientData clientData,	/* Not used. */
  Tcl_Interp *interp,		/* Current interpreter */
  int objc,			/* Number of arguments */
  Tcl_Obj *const objv[]	/* Argument strings */
)
{
  double start, end, data_end;
  char *inpath, *outpath;
  int nocomp = 0;
  long numRecs;
  DOBJ *smpPtr, *outPtr;

  switch ( objc )
    {
    case 5:
      inpath = Tcl_GetString(objv[1]);
      if (Tcl_GetDoubleFromObj (interp, objv[2], &start) == TCL_ERROR)
        return TCL_ERROR;
      if (Tcl_GetDoubleFromObj (interp, objv[3], &end) == TCL_ERROR)
        return TCL_ERROR;
      outpath = Tcl_GetString(objv[4]);
      break;
    case 6:
      if (strcmp(Tcl_GetString(objv[1]), "-nocomplain") != 0)
        {
          Tcl_WrongNumArgs ( interp, 1, objv, "?-nocomplain? infile start end outfile" );
          return TCL_ERROR;
        }
      else
        nocomp = 1;
      inpath = Tcl_GetString(objv[2]);
      if (Tcl_GetDoubleFromObj (interp, objv[3], &start) == TCL_ERROR)
        return TCL_ERROR;
      if (Tcl_GetDoubleFromObj (interp, objv[4], &end) == TCL_ERROR)
        return TCL_ERROR;
      outpath = Tcl_GetString(objv[5]);
      break;
    default:
      Tcl_WrongNumArgs ( interp, 1, objv, "?-nocomplain? infile start end outfile" );
      return TCL_ERROR;
    }
//read infile
  if ((smpPtr = asspFOpen ( inpath, AFO_READ, (DOBJ*)NULL ) ) == NULL)
  {
    Tcl_SetResult (interp, getAsspMsg ( asspMsgNum ), TCL_VOLATILE);
    return TCL_ERROR;
  }
 
  //check times
  //if start is before begin of data, set start to begin of data
  data_end = SMPNRtoTIME(smpPtr->startRecord + smpPtr->numRecords, smpPtr->dataRate);
  data_end = foreignTime(data_end, smpPtr, FALSE);
  if (start >= data_end)
    {
      if (nocomp)
        start = smpPtr->Start_Time;
      else
        {
          Tcl_SetResult(interp, "Start time after end of data", TCL_VOLATILE);
          return TCL_ERROR;
        }
    }
  if (start < smpPtr->Start_Time)
    {
      if (nocomp || start == 0)
        start = smpPtr->Start_Time;
      else
        {
          Tcl_SetResult(interp, "Start time before begin of data.",
                        TCL_VOLATILE);
          return TCL_ERROR;
        }
    }
  if ( end < smpPtr->Start_Time)
    {
      if (nocomp || start == 0)
        end = data_end;
      else
        {
          Tcl_SetResult(interp, "End time before begin of data", TCL_VOLATILE);
          return TCL_ERROR;
        }
    }
  if (end >= data_end)
    {
      if (nocomp)
        end = data_end;
      else
        {
          Tcl_SetResult(interp, "End time after end of data.", TCL_VOLATILE);
          return TCL_ERROR;
        }
    }
  numRecs = TIMEctSMPNR(end-start, smpPtr->dataRate);
  allocDataBuf(smpPtr, numRecs);
  smpPtr->bufStartRec =  TIMEtoSMPNR(start, smpPtr->dataRate);
  if (asspFFill(smpPtr) == -1)
    {
      Tcl_SetResult(interp, getAsspMsg ( asspMsgNum ), TCL_VOLATILE);
      asspFClose(smpPtr, AFC_FREE);
      return TCL_ERROR;
    }
  if ((outPtr = allocDObj()) == NULL)
  {
    Tcl_SetResult(interp, getAsspMsg ( asspMsgNum ), TCL_VOLATILE);
    asspFClose(smpPtr, AFC_FREE);
    return TCL_ERROR;
  }
  if (copyDObj(outPtr, smpPtr) == -1)
    {
      Tcl_SetResult(interp, getAsspMsg ( asspMsgNum ), TCL_VOLATILE);
      asspFClose(smpPtr, AFC_FREE);
      return TCL_ERROR;
    }
  outPtr->dataBuffer = smpPtr->dataBuffer;
  outPtr->Start_Time = 0;
  outPtr->numRecords = numRecs;
  outPtr->startRecord = 0;
  outPtr->bufStartRec = 0;
  outPtr->maxBufRecs = numRecs;
  outPtr->bufNumRecs = smpPtr->bufNumRecs;
  outPtr->filePath = outpath;
  if ( ( outPtr=asspFOpen ( outPtr->filePath, AFO_WRITE, outPtr ) ) == NULL )
    {
      outPtr->dataBuffer = NULL;
      Tcl_SetResult(interp, getAsspMsg ( asspMsgNum ), TCL_VOLATILE);
      asspFClose(smpPtr, AFC_FREE);
      asspFClose(outPtr, AFC_CLEAR);
      return TCL_ERROR;
    }
  if (asspFFlush(outPtr, 0) == -1)
    {
      Tcl_SetResult(interp, getAsspMsg ( asspMsgNum ), TCL_VOLATILE);
      asspFClose(smpPtr, AFC_FREE);
      asspFClose(outPtr, AFC_CLEAR);
      return TCL_ERROR;
    }
  asspFClose(smpPtr, AFC_FREE);
  asspFClose(outPtr, AFC_CLEAR);
  return TCL_OK;
}



