/***************************************************************************
 *            rmsana.c
 *
 *  Fri May 18 15:14:12 2007
 *  Copyright  2007  User
 *  Email
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
 /* $Id: ffinfo.c,v 1.7 2008/03/22 12:24:22 lasselasse Exp $ */
#include <tcl.h>
#include <string.h>     /* str... */
#include <errno.h>
#include <misc.h>
#include <dataobj.h>
//#include <assp.h>

#include <ipds_lbl.h>
#include <asspana.h>
#include <asspmess.h>
#include <assptime.h>  /*smp2dur*/
#include <headers.h>   /*getHeader*/
#include "tclassp.h"

int smpInfo  (DOBJ *dop, Tcl_DString *error, Tcl_DString *res);
int tagInfo  (DOBJ *dop, Tcl_DString *error, Tcl_DString *res);
int asspInfo (DOBJ *dop, Tcl_DString *error, Tcl_DString *res);
int ssffInfo (DOBJ *dop, Tcl_DString *error, Tcl_DString *res);
int uwmInfo  (DOBJ *dop, Tcl_DString *error, Tcl_DString *res);


int ffinfo_Cmd (
  ClientData clientData,	/* Not used. */
  Tcl_Interp *interp,		/* Current interpreter */
  int objc,			/* Number of arguments */
  Tcl_Obj *const objv[]	/* Argument strings */
)
{
  if (objc != 2)
    {
      Tcl_WrongNumArgs(interp, 1, objv, "file");
      return TCL_ERROR;
    }
  int err;
  DOBJ dobj, *dop;
  dop = &dobj;
  Tcl_DString *error, Error, *res, Res;
  DDESC *dd;
  error = &Error;
  res = &Res;
  Tcl_DStringInit(error);
  Tcl_DStringInit(res);
  initDObj(dop);

  clrAsspMsg();
  dop->filePath = Tcl_GetString(objv[1]);
  dop->fp=fopen(dop->filePath, "rb");
  if (dop->fp == NULL)
    {
      Tcl_DStringAppend(error, getAsspMsg(AEF_ERR_OPEN), -1);
      Tcl_DStringAppend(error, ": ", -1);
      Tcl_DStringAppend(error, dop->filePath, -1);
      Tcl_DStringResult(interp, error);
      return TCL_ERROR;
    }
  err = getHeader(dop);
  if (err && asspMsgNum != AEF_BAD_FORM)
    {
      if (err < 0)
        {
          Tcl_DStringAppend(error, getAsspMsg(AEF_ERR_OPEN), -1);
          Tcl_DStringAppend(error, ": ", -1);
          Tcl_DStringAppend(error, applMessage, -1);
          Tcl_DStringResult(interp, error);
          Tcl_DStringFree(res);
          return TCL_ERROR;
        }
      prtAsspMsg(NULL);
    }
  Tcl_DStringAppendElement(res,"file_name");
  Tcl_DStringAppendElement(res,dop->filePath);

  dd = &(dop->ddl);
  switch (dd->type)
    {
    case DT_SMP:
      smpInfo(dop,error,res);
      break;
    case DT_TAG:
    case DT_LBL:
    case DT_MRK:
    case DT_EPO:
    case DT_PRD:
      tagInfo(dop,error,res);
      break;
    default:                                       /* parametric data */
      switch (dop->fileFormat)
        {
        case FF_XASSP:
	  asspInfo(dop,error,res);
          break;
        case FF_SSFF:
	  ssffInfo(dop,error,res);
          break;
        case FF_UWM:
	  uwmInfo(dop,error,res);
          break;
        default:
	  Tcl_DStringAppendElement(res,"file_format");
	  Tcl_DStringAppendElement(res,"UNKNOWN");
	  Tcl_DStringAppendElement(res,"data_format");
          fflush(stdout);
          if (dop->fileData == FDF_ASC)
	    Tcl_DStringAppendElement(res,"ASCII");
          else if (dop->fileData == FDF_BIN)
	    Tcl_DStringAppendElement(res,"BINARY");
          else
	    Tcl_DStringAppendElement(res,"UNKNOWN");
          err = TRUE;
        }
      break;
    }
  clearDObj(dop);
  Tcl_DStringResult(interp, res);
  Tcl_DStringFree(error);
  return TCL_OK;
}

int smpInfo  (DOBJ *dop, Tcl_DString *error, Tcl_DString *res)
{
  int    nd, HANDLE;
  DDESC *dd=&(dop->ddl);
  char temp[256];

  HANDLE = TRUE;
  Tcl_DStringAppendElement(res, "file_format");
  fflush(stdout);
  switch (dop->fileFormat)
    {
    case FF_RAW:
      Tcl_DStringAppendElement(res, "RAW");
      break;
    case FF_KTH:
      Tcl_DStringAppendElement(res, "KTH");
      break;
    case FF_AIFF:
      Tcl_DStringAppendElement(res, "AIFF");
      break;
    case FF_AIFC:
      Tcl_DStringAppendElement(res, "AIFC");
      break;
    case FF_AU:
      Tcl_DStringAppendElement(res, "AU/SND");
      break;
    case FF_CSL:
      Tcl_DStringAppendElement(res, "CSL");
      break;
    case FF_CSRE:
      Tcl_DStringAppendElement(res, "CSRE");
      break;
    case FF_NIST:
      Tcl_DStringAppendElement(res, "NIST-SPHERE");
      break;
    case FF_SSFF:
      Tcl_DStringAppendElement(res, "SSFF");
      break;
    case FF_WAVE:
      Tcl_DStringAppendElement(res, "RIFF-WAVE");
      break;
    default:
      Tcl_DStringAppendElement(res, "UNKNOWN");
      HANDLE = FALSE;
    }
  Tcl_DStringAppendElement(res, "header_size");
  sprintf(temp, "%li", dop->headerSize);
  Tcl_DStringAppendElement(res, temp);
  if (dop->fileFormat == FF_SSFF)
    {
      Tcl_DStringAppendElement(res, "ssff_keyword");
      Tcl_DStringAppendElement(res,  dd->ident);
    }
  Tcl_DStringAppendElement(res, "data_type");
  Tcl_DStringAppendElement(res, "audio");
  Tcl_DStringAppendElement(res, "data_format");
  switch (dd->format)
    {
    case DF_STR:
      Tcl_DStringAppendElement(res, "ASCII");
      break;
    case DF_BIT:
      Tcl_DStringAppendElement(res, "BIT");
      break;
    case DF_CHAR:
      Tcl_DStringAppendElement(res, "CHAR");
      break;
    case DF_UINT8:
      Tcl_DStringAppendElement(res, "INT8_unsigned");
      break;
    case DF_INT8:
      Tcl_DStringAppendElement(res, "INT8");
      break;
    case DF_UINT16:
      Tcl_DStringAppendElement(res, "INT16_unsigned");
      break;
    case DF_INT16:
      Tcl_DStringAppendElement(res, "INT16");
      break;
    case DF_UINT24:
      Tcl_DStringAppendElement(res, "INT24_unsigned");
      break;
    case DF_INT24:
      Tcl_DStringAppendElement(res, "INT24");
      break;
    case DF_UINT32:
      Tcl_DStringAppendElement(res, "INT32_unsigned");
      break;
    case DF_INT32:
      Tcl_DStringAppendElement(res, "INT32");
      break;
    case DF_UINT64:
      Tcl_DStringAppendElement(res, "INT64_unsigned");
      break;
    case DF_INT64:
      Tcl_DStringAppendElement(res, "INT64");
      break;
    case DF_REAL32:
      Tcl_DStringAppendElement(res, "FLOAT");
      break;
    case DF_REAL64:
      Tcl_DStringAppendElement(res, "DOUBLE");
      break;
      /*     case DF_REAL80: */
      /*       Tcl_DStringAppendElement(res, "XFLOAT"); */
      /*       break; */
      /*     case DF_REAL128: */
      /*       Tcl_DStringAppendElement(res, "QFLOAT"); */
      /*       break; */
    default:
      Tcl_DStringAppendElement(res, "UNKNOWN");
      HANDLE = FALSE;
    }
  Tcl_DStringAppendElement(res, "data_coding");
  fflush(stdout);
  switch (dd->coding)
    {
    case DC_PCM:
      Tcl_DStringAppendElement(res, "PCM");
      break;
    case DC_ALAW:
      Tcl_DStringAppendElement(res, "A-LAW");
      break;
    case DC_uLAW:
      Tcl_DStringAppendElement(res, "u-LAW");
      break;
    case DC_DELTA:
      Tcl_DStringAppendElement(res, "DELTA");
      HANDLE = FALSE;
      break;
    case DC_ACE2:
    case DC_ACE8:
      Tcl_DStringAppendElement(res, "Apple_compressed");
      HANDLE = FALSE;
      break;
    case DC_MAC3:
    case DC_MAC6:
      Tcl_DStringAppendElement(res, "Mac_compressed");
      HANDLE = FALSE;
      break;
    case DC_ADPCM:
    case DC_G721:
    case DC_G722:
    case DC_G723_3:
    case DC_G723_5:
    case DC_MS_ADPCM:
    case DC_CL_ADPCM:
    case DC_IDVI_ADPCM:
    case DC_OKI_ADPCM:
    case DC_IBM_ADPCM:
      Tcl_DStringAppendElement(res, "ADPCM");
      HANDLE = FALSE;
      break;
    case DC_MPEG3:
      Tcl_DStringAppendElement(res, "MP3");
      HANDLE = FALSE;
      break;
    default:
      Tcl_DStringAppendElement(res, "UNKNOWN");
      HANDLE = FALSE;
      break;
    }
  if (dd->numBits > 8)
    {
      Tcl_DStringAppendElement(res, "byte_order");
      fflush(stdout);
      if (MSBFIRST(dop->fileEndian))
        Tcl_DStringAppendElement(res, "MSB_first");
      else if (MSBLAST(dop->fileEndian))
        Tcl_DStringAppendElement(res, "MSB_last");
      else
        Tcl_DStringAppendElement(res, "UNDEFINED");
    }
  Tcl_DStringAppendElement(res, "bits/sample");
  sprintf(temp, "%i", dd->numBits);
  Tcl_DStringAppendElement(res, temp);
  Tcl_DStringAppendElement(res, "sample_rate");
  nd = numDecim(dop->sampFreq, 11) + 1;
  sprintf(temp, "%.*f", nd, dop->sampFreq);
  Tcl_DStringAppendElement(res, temp);
  Tcl_DStringAppendElement(res, "number_channels");
  sprintf(temp, "%i", dd->numFields);
  Tcl_DStringAppendElement(res, temp);
  if (HANDLE)
    {
      Tcl_DStringAppendElement(res, "samples/channel");
      sprintf(temp, "%li", dop->numRecords);
      Tcl_DStringAppendElement(res, temp);
    }
  if (dop->fileFormat == FF_SSFF)
    {
      Tcl_DStringAppendElement(res, "start_time");
      sprintf(temp, "%f", dop->Start_Time);
      Tcl_DStringAppendElement(res, temp);
    }
  if (HANDLE)
    {
      Tcl_DStringAppendElement(res, "duration");
      Tcl_DStringAppendElement(res,smp2dur(dop->numRecords,
                                           dop->sampFreq));
    }
  return TCL_OK;
}

int tagInfo  (DOBJ *dop, Tcl_DString *error, Tcl_DString *res)
{
  int    nd;
  DDESC *dd=&(dop->ddl);
  char temp[256];

  Tcl_DStringAppendElement(res, "file_format");
  fflush(stdout);
  switch(dop->fileFormat) {
    case FF_RAW:
      Tcl_DStringAppendElement(res, "RAW");
      break;
    case FF_XASSP:
      Tcl_DStringAppendElement(res, "XASSP");
      break;
    case FF_IPDS_M:
      Tcl_DStringAppendElement(res, "IPdS_MIX");
      if(dop->sampFreq <= 0.0)                /* not specified in header */
	dop->sampFreq = MIX_SFR;
      break;
    case FF_IPDS_S:
      Tcl_DStringAppendElement(res, "IPdS_SAMPA");
      if(dop->sampFreq <= 0.0)                /* not specified in header */
	dop->sampFreq = MIX_SFR;
      break;
    case FF_ESPS:
      Tcl_DStringAppendElement(res, "ESPS_XLBL");
      break;
    default:
      Tcl_DStringAppendElement(res, "UNKNOWN");
      break;
  }
  Tcl_DStringAppendElement(res, "header_size");
  sprintf(temp, "%li", dop->headerSize);
  Tcl_DStringAppendElement(res, temp);
  Tcl_DStringAppendElement(res, "data_type");
  fflush(stdout);
  switch(dd->type) {
    case DT_TAG:
      if(dd->ident)
	Tcl_DStringAppendElement(res, dd->ident);
      else
	Tcl_DStringAppendElement(res, "tags");
      break;
    case DT_MRK:
      if(dd->ident)
	Tcl_DStringAppendElement(res, dd->ident);
      else
	Tcl_DStringAppendElement(res, "marks");
      break;
    case DT_LBL:
      if(dd->ident)
	Tcl_DStringAppendElement(res, dd->ident);
      else
	Tcl_DStringAppendElement(res, "labels");
      break;
    case DT_EPO:
      if(dd->ident)
	Tcl_DStringAppendElement(res, dd->ident);
      else
	Tcl_DStringAppendElement(res, "epochs");
      break;
    case DT_PRD:
      if(dd->ident)
	Tcl_DStringAppendElement(res, dd->ident);
      else
	Tcl_DStringAppendElement(res, "period_markers");
      break;
    default:
      if(dd->ident)
	Tcl_DStringAppendElement(res, dd->ident);
      else
	Tcl_DStringAppendElement(res, "UNKNOWN");
      break;
  }
  if(dop->fileData == FDF_ASC) {
    Tcl_DStringAppendElement(res, "data_format");
    Tcl_DStringAppendElement(res, "ASCII");
  }
  else {
    Tcl_DStringAppendElement(res, "data_format");
    Tcl_DStringAppendElement(res, "NON-ASCII");
  }
  if(dop->sampFreq > 0.0) {
    nd = numDecim(dop->sampFreq, 11) + 1;
    sprintf(temp, "%.*f", nd, dop->sampFreq);
    Tcl_DStringAppendElement(res, "sample_rate");
    Tcl_DStringAppendElement(res, temp);
  }
  else {
    Tcl_DStringAppendElement(res, "sample_rate");
    Tcl_DStringAppendElement(res, "UNDEFINED");
  }
  sprintf(temp, "%ld", (long)(dd->numFields));
  Tcl_DStringAppendElement(res, "number_tiers");
  Tcl_DStringAppendElement(res, temp);

  return TCL_OK; 
}

int asspInfo (DOBJ *dop, Tcl_DString *error, Tcl_DString *res)
{
  int    nd;
  DDESC *dd=&(dop->ddl);
  char temp[256];
  
  Tcl_DStringAppendElement(res, "file_format");
  Tcl_DStringAppendElement(res, "XASSP");
  Tcl_DStringAppendElement(res, "header_size");
  sprintf(temp, "%li", dop->headerSize);
  Tcl_DStringAppendElement(res, temp);
  Tcl_DStringAppendElement(res, "data_type");
  switch(dd->type) {
    case DT_RMS:
      sprintf(temp,"energy");
      break;
    case DT_PIT:
      sprintf(temp,"pitch");
      break;
    case DT_ZCR:
      sprintf(temp,"zero-crossing_rate");
      break;
    case DT_EPG:
      sprintf(temp,"palatogram");
      break;
    case DT_AMP:
      sprintf(temp,"amplification");
      break;
    case DT_DUR:
      sprintf(temp,"lengthening");
      break;
    case DT_DATA_LOG:
      sprintf(temp,"datalog");
      break;
    default:
      sprintf(temp,"UNKNOWN");
  }
  if(strlen(dd->unit)) {
    if(strlen(dd->factor))
      sprintf(temp,"%s (%s%s)", temp, dd->factor, dd->unit);
    else
      sprintf(temp,"%s (%s)", temp, dd->unit);
  }
  Tcl_DStringAppendElement(res, temp);
  Tcl_DStringAppendElement(res, "data_format");
  Tcl_DStringAppendElement(res, "ASCII");
  if(dop->dataRate > 0.0) {
    nd = numDecim(dop->dataRate, 12);
    if(nd <= 0) nd = 1;
    sprintf(temp, "%.*f", nd, dop->dataRate);
    Tcl_DStringAppendElement(res, "frame_rate");
    Tcl_DStringAppendElement(res, temp);
  }
  if(dop->sampFreq > 0.0) {
    nd = numDecim(dop->sampFreq, 12);
    if(nd <= 0) nd = 1;
    sprintf(temp, "%.*f", nd, dop->sampFreq);
    Tcl_DStringAppendElement(res, "sample_rate");
    Tcl_DStringAppendElement(res, temp);
  }
  if(dop->frameDur > 1) {
    Tcl_DStringAppendElement(res, "samples/frame");
    sprintf(temp, "%ld", dop->frameDur);
    Tcl_DStringAppendElement(res, temp);
  }
  Tcl_DStringAppendElement(res, "start_frame");
  sprintf(temp, "%ld", dop->startRecord);
  Tcl_DStringAppendElement(res, temp);
  if(dop->numRecords > 0) {
    Tcl_DStringAppendElement(res, "number_frames");
    sprintf(temp, "%ld", dop->numRecords);
    Tcl_DStringAppendElement(res, temp);
    if(dop->sampFreq > 0.0 && dop->frameDur > 0) {
      Tcl_DStringAppendElement(res, "duration");
      Tcl_DStringAppendElement(res, smp2dur(dop->numRecords,
			       dop->sampFreq / (double)dop->frameDur));
    }
  }

  return TCL_OK; 
}

int ssffInfo (DOBJ *dop, Tcl_DString *error, Tcl_DString *res)
{
  int    nd;
  DDESC *dd=&(dop->ddl);
  char temp[256];

  Tcl_DStringAppendElement(res, "file_format");
  Tcl_DStringAppendElement(res, "SSFF");
  Tcl_DStringAppendElement(res, "header_size");
  sprintf(temp, "%ld", dop->headerSize);
  Tcl_DStringAppendElement(res, temp);
  Tcl_DStringAppendElement(res, "byte_order");
  if(MSBFIRST(dop->fileEndian))
    Tcl_DStringAppendElement(res, "MSB_first");
  else if(MSBLAST(dop->fileEndian))
    Tcl_DStringAppendElement(res, "MSB_last");
  else
    Tcl_DStringAppendElement(res, "UNDEFINED");
  if(dop->dataRate > 0.0) {
    nd = numDecim(dop->dataRate, 12);
    if(nd <= 0) nd = 1;
    Tcl_DStringAppendElement(res, "data_rate");
    sprintf(temp, "%.*f", nd, dop->dataRate);
    Tcl_DStringAppendElement(res, temp);
  }
  else {
    Tcl_DStringAppendElement(res, "data_rate");
    Tcl_DStringAppendElement(res, "UNDEFINED");
}
  if(dop->sampFreq > 0.0) {
    nd = numDecim(dop->sampFreq, 12);
    if(nd <= 0) nd = 1;
    Tcl_DStringAppendElement(res, "sample_rate");
    sprintf(temp, "%.*f", nd, dop->sampFreq);
    Tcl_DStringAppendElement(res, temp);
  }
  else if(dop->frameDur < 0) {
    Tcl_DStringAppendElement(res, "sample_rate");
    Tcl_DStringAppendElement(res, "UNDEFINED");
  }
  if(dop->numRecords > 0) {
    Tcl_DStringAppendElement(res, "number_frames");
    sprintf(temp, "%ld", dop->numRecords);
    Tcl_DStringAppendElement(res, temp);
  }
  nd = numDecim(dop->Start_Time, 12);
  if(nd <= 0) 
    nd = 1;
  Tcl_DStringAppendElement(res, "start_time");
  sprintf(temp, "%.*f", nd, dop->Start_Time);
  Tcl_DStringAppendElement(res, temp);
  if(dop->numRecords > 0) {
    if(dop->dataRate > 0.0) {
      Tcl_DStringAppendElement(res, "duration");
      Tcl_DStringAppendElement(res, smp2dur(dop->numRecords,
			       dop->dataRate));
    }
    else if(dop->sampFreq > 0.0) {
      Tcl_DStringAppendElement(res, "duration");
      Tcl_DStringAppendElement(res, smp2dur(dop->numRecords,
			       dop->sampFreq));
    }
  }
  while(dd) {
    Tcl_DStringAppendElement(res, "ssff_keyword");
    Tcl_DStringAppendElement(res, dd->ident);
    Tcl_DStringAppendElement(res, "data_type");
    fflush(stdout);
    switch(dd->type) {
      case DT_RMS:
	sprintf(temp, "RMS");
	break;
      case DT_GAIN:
	sprintf(temp, "gain");
	break;
      case DT_PIT:
	sprintf(temp, "pitch");
	break;
      case DT_ZCR:
	sprintf(temp, "zero-crossing_rate");
	break;
      case DT_ACF:
	sprintf(temp, "autocorrelation_function");
	break;
      case DT_LPC:
	sprintf(temp, "linear_prediction_coefficients");
	break;
      case DT_RFC:
	sprintf(temp, "reflection_coefficients");
	break;
      case DT_ARF:
	sprintf(temp, "area_function");
	break;
      case DT_LAR:
	sprintf(temp, "log_area_ratio");
	break;
      case DT_FFR:
	sprintf(temp, "formant_frequency");
	break;
      case DT_FBW:
	sprintf(temp, "formant_bandwidth");
	break;
      case DT_FAM:
	sprintf(temp, "formant_amplitude");
	break;
      case DT_FTAMP:
	sprintf(temp, "amplitude_spectrum");
	break;
      case DT_FTPOW:
	sprintf(temp, "power_spectrum");
	break;
      case DT_FTLPS:
	sprintf(temp, "LP_smoothed_spectrum");
	break;
      case DT_FTCSS:
	sprintf(temp, "cepstrally_smoothed_spectrum");
	break;
      case DT_CEP:
	sprintf(temp, "cepstral_coefficients");
	break;
      case DT_EPG:
	sprintf(temp, "palatogram");
	break;
      default:
	sprintf(temp, "UNKNOWN");
    }
    if(strlen(dd->unit)) {
      if(strlen(dd->factor))
	sprintf(temp, "%s (%s%s)", temp, dd->factor, dd->unit);
      else
	sprintf(temp, "%s (%s)", temp, dd->unit);
    }
    Tcl_DStringAppendElement(res, temp);
    Tcl_DStringAppendElement(res, "data_format");
    fflush(stdout);
    switch(dd->format) {
      case DF_CHAR:
	Tcl_DStringAppendElement(res, "CHAR");
	break;
      case DF_UINT8:
	Tcl_DStringAppendElement(res, "INT8_unsigned");
	break;
      case DF_INT16:
	Tcl_DStringAppendElement(res, "INT16");
	break;
      case DF_INT32:
	Tcl_DStringAppendElement(res, "INT32");
	break;
      case DF_REAL32:
	Tcl_DStringAppendElement(res, "FLOAT");
	break;
      case DF_REAL64:
	Tcl_DStringAppendElement(res, "DOUBLE");
	break;
      default:
	Tcl_DStringAppendElement(res, "UNKNOWN");
    }
    Tcl_DStringAppendElement(res, "number_fields");
    sprintf(temp, "%ld", (long)(dd->numFields));
    Tcl_DStringAppendElement(res, temp);
    dd = dd->next;
  }   /* end loop over data descriptors */

  return TCL_OK; 
}

int uwmInfo  (DOBJ *dop, Tcl_DString *error, Tcl_DString *res)
{
  int    nd;
  DDESC *dd=&(dop->ddl);
  char temp[256];

  Tcl_DStringAppendElement(res, "file_format");
  Tcl_DStringAppendElement(res, "WISCONSIN");
  Tcl_DStringAppendElement(res, "header_size");
  sprintf(temp, "%ld", dop->headerSize);
  Tcl_DStringAppendElement(res, temp);
  Tcl_DStringAppendElement(res, "data_type");
  Tcl_DStringAppendElement(res, "X-ray_microbeam");
  Tcl_DStringAppendElement(res, "data_format");
  Tcl_DStringAppendElement(res, "ASCII");
  if(dd->coding == DC_TXY) {
    Tcl_DStringAppendElement(res, "data_coding");
    Tcl_DStringAppendElement(res, "TXY");
  }
  else {
    Tcl_DStringAppendElement(res, "data_coding");
    Tcl_DStringAppendElement(res, "XYD");
  }
  Tcl_DStringAppendElement(res, "number_fields");
  sprintf(temp, "%ld", (long)(dd->numFields));
  Tcl_DStringAppendElement(res, temp);
  nd = numDecim(dop->sampFreq, 11) + 1;
  Tcl_DStringAppendElement(res, "sample_rate");
  sprintf(temp, "%.*f", nd, dop->sampFreq);
  Tcl_DStringAppendElement(res, temp);
  Tcl_DStringAppendElement(res, "samples/frame");
  sprintf(temp, "%ld", dop->frameDur);
  Tcl_DStringAppendElement(res, temp);
  if(dop->numRecords > 0) {
    Tcl_DStringAppendElement(res, "number_frames");
    sprintf(temp, "%ld", dop->numRecords);
    Tcl_DStringAppendElement(res, temp);
    if(dop->sampFreq > 0.0 && dop->frameDur > 0) {
      Tcl_DStringAppendElement(res, "duration");
      Tcl_DStringAppendElement(res, smp2dur(dop->numRecords,
			       dop->sampFreq / (double)dop->frameDur));
    }
  }

  return TCL_OK; 
}

