/***************************************************************************
 *            rmsana.c
 *
 *  Fri May 18 15:14:12 2007
 *  Copyright  2007  User
 *  Email
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
 /* $Id: rmsana.c,v 1.17 2008/03/22 12:24:22 lasselasse Exp $ */
#include <tcl.h>
#include <string.h>     /* str... */
#include <errno.h>
#include <misc.h>
#include <asspfio.h>
#include <dataobj.h>
//#include <assp.h>

#include <ipds_lbl.h>
#include <asspana.h>
#include <asspmess.h>
#include "tclassp.h"

int rmsana_Cmd (
  ClientData clientData,	/* Not used. */
  Tcl_Interp *interp,		/* Current interpreter */
  int objc,			/* Number of arguments */
  Tcl_Obj *const objv[]	/* Argument strings */
)
{
  int ascii=0, flush=0, a, filec, argc;
  int have_ext=0, have_oDir=0, have_win=0;
  //callback variables: counter and stop
  int have_counter = 0, counter = 0, have_stop = 0, stop = 0;
  const char *svar=NULL, *cvar=NULL;
  char *ext=NULL;
  const char **argv;
  char *opt, result[1024];
  CONST char *pathv[2];
  Tcl_Obj **filev, *buf;
  Tcl_Obj *errVar = Tcl_NewStringObj("::tclassp::errors", -1), *warnVar = Tcl_NewStringObj("::tclassp::warnings", -1);
  Tcl_DString dir, outPath;
  DOBJ *smpPtr, *outPtr;
  AOPTS OPTS;
  AOPTS *opts=&OPTS;
  if ( setRMSdefaults ( opts ) ==-1 )
    {
      Tcl_SetResult ( interp, getAsspMsg ( asspMsgNum ), TCL_VOLATILE );
      return TCL_ERROR;
    }
  double *optPtr;
  static const char *options[] =
  {
    "-begin", "-end", "-winShift", "-winSize", "-ascii", "-outDir", "-extension", "-flush", "-window", "-linVals",
    "-counter", "-stop", NULL
  };
  enum AsspOpts
  {
    ASSPOPT_BEGIN, ASSPOPT_END, ASSPOPT_WINSHIFT, ASSPOPT_WINSIZE,
    ASSPOPT_ASCII, ASSPOPT_OUTDIR, ASSPOPT_EXTENSION, ASSPOPT_FLUSH,
    ASSPOPT_WINDOW, ASSPOPT_LINVALS, ASSPOPT_COUNTER, ASSPOPT_STOP
  };
  /*  static const char *windows[] =
      {
        "rectangle", "triangle", "blackman", "hanning", "hamming", NULL
      };*/
  //reset errors and warnings
  /*  warnVar = Tcl_SetVar2Ex ( interp, "::tclassp::warnings", NULL,
                              Tcl_NewStringObj ( "",-1 ), TCL_LEAVE_ERR_MSG );
    errVar = Tcl_SetVar2Ex ( interp, "::tclassp::errors", NULL,
                             Tcl_NewStringObj ( "",-1 ), TCL_LEAVE_ERR_MSG );*/
  Tcl_ObjSetVar2(interp, errVar, NULL, Tcl_NewStringObj("", -1), TCL_LEAVE_ERR_MSG );
  Tcl_ObjSetVar2(interp, warnVar, NULL, Tcl_NewStringObj("", -1), TCL_LEAVE_ERR_MSG );
  if ( objc < 2 )
    {
      Tcl_WrongNumArgs ( interp, 1, objv, "?options? filename" );
      return TCL_ERROR;
    }
  for ( a = 1; a < objc; a++ )
    {
      int index, tmp;
      opt = Tcl_GetString ( objv[a] );
      if ( opt[0] != '-' )
        break; //the rest is filenames
      if ( Tcl_GetIndexFromObj ( interp, objv[a], options, "option", 0,
                                 &index ) ==TCL_ERROR )
        return TCL_ERROR;
      //all args take an argument except ascii and flush
      if ( ( index != ASSPOPT_ASCII ) && ( index != ASSPOPT_FLUSH )  &&
           ( index != ASSPOPT_LINVALS ) &&
           ( ++a >= objc - 1 ) )
        {
          Tcl_WrongNumArgs ( interp, 2, objv, "?options? fileList" );
          return TCL_ERROR;
        }
      if ( ( ( index == ASSPOPT_EXTENSION ) || ( index == ASSPOPT_OUTDIR ) || (index == ASSPOPT_COUNTER) ||
             (index == ASSPOPT_WINDOW) || (index ==ASSPOPT_STOP) ) &&
           ( Tcl_GetIndexFromObj ( interp, objv[a], options, "option", 0,
                                   &tmp ) ==TCL_OK ) )
        {
          sprintf ( result, "Option %s requires an argument:", options[index] );
          Tcl_SetResult ( interp, result, TCL_VOLATILE );
          return TCL_ERROR;
        }
      switch ( ( enum AsspOpts ) index )
        {
          //get booleans first
        case ASSPOPT_ASCII:
          ascii=1;
          Tcl_SetResult ( interp,
                          "ASCII output not supported yet",
                          TCL_VOLATILE );
          return TCL_ERROR;
          break;
        case ASSPOPT_FLUSH:
          flush=1;
          Tcl_SetResult ( interp,
                          "Redirecting output to TCL not supported yet (-flush)",
                          TCL_VOLATILE );
          return TCL_ERROR;
          break;
        case ASSPOPT_LINVALS:
          opts->options |= RMS_OPT_LINEAR;
          break;
          //now get opts with args
        case ASSPOPT_BEGIN:
          optPtr=& ( opts->beginTime );
          if ( Tcl_GetDoubleFromObj ( interp, objv[a], & ( opts->beginTime ) ) != TCL_OK )
            {
              return TCL_ERROR;
            }
          break;
        case ASSPOPT_END:
          if ( Tcl_GetDoubleFromObj ( interp, objv[a], & ( opts->endTime ) ) != TCL_OK )
            {
              return TCL_ERROR;
            }
          break;
        case ASSPOPT_WINSHIFT:
          if ( Tcl_GetDoubleFromObj ( interp, objv[a], & ( opts->msShift ) ) != TCL_OK )
            {
              return TCL_ERROR;
            }
          break;
        case ASSPOPT_WINSIZE:
          if ( Tcl_GetDoubleFromObj ( interp, objv[a], & ( opts->msSize ) ) != TCL_OK )
            {
              return TCL_ERROR;
            }
          break;
        case ASSPOPT_OUTDIR:
          pathv[0]=Tcl_GetString ( objv[a] );
          have_oDir=1;
          break;
        case ASSPOPT_EXTENSION:
          ext = Tcl_GetString ( objv[a] );
          have_ext=1;
          break;
        case ASSPOPT_WINDOW:
          if ( Tcl_GetIndexFromObj ( interp, objv[a], windows, "window", 0,
                                     &tmp ) !=TCL_OK )
            return TCL_ERROR;
          strcpy ( opts->winFunc,windows[tmp] );
          have_win=1;
          break;
        case ASSPOPT_COUNTER:
          cvar = Tcl_GetString(objv[a]);
          if (Tcl_GetIntFromObj(interp, Tcl_GetVar2Ex(interp, cvar, NULL,
                                TCL_LEAVE_ERR_MSG),&counter) != TCL_OK)
            return TCL_ERROR;
          if (Tcl_LinkVar(interp, Tcl_GetString( objv[a] ), (char *) &counter, TCL_LINK_INT)!=TCL_OK)
            return TCL_ERROR;
          have_counter=1;
          break;
        case ASSPOPT_STOP:
          svar = Tcl_GetString(objv[a]);
          if (Tcl_GetIntFromObj(interp, Tcl_GetVar2Ex(interp, svar, NULL,
                                TCL_LEAVE_ERR_MSG),&stop) != TCL_OK)
            return TCL_ERROR;
          if (Tcl_LinkVar(interp, svar, (char *)&stop, TCL_LINK_INT)!=TCL_OK)
            return TCL_ERROR;
          have_stop=1;
          break;
        }
    }
  //use center time if begin time equals end time (event handling)
  if (opts->beginTime == opts->endTime && opts->beginTime != -1)
    {
      opts->centreTime = opts->beginTime;
      opts->beginTime = opts->endTime = -1;
    }
  int i = 0;
  if ( !have_oDir )
    {
      if ( Tcl_GetCwd ( interp, &dir ) ==NULL )
        return TCL_ERROR;
      pathv[0]= Tcl_DStringValue ( &dir );
      Tcl_DStringFree ( &dir );
    }
  /*  sprintf(opt, "file nativename %s", pathv[0]);
    printf(opt);
    if (Tcl_EvalEx(interp, opt, -1, TCL_EVAL_DIRECT) == TCL_ERROR)
    {
      return TCL_ERROR;
    }
    pathv[0]=Tcl_GetString(Tcl_GetObjResult(interp));*/
  if ( !have_ext )
    ext="rms";
  if ( !have_win )
    strcpy ( opts->winFunc,"blackman" );
  if ( a >= objc )
    {
      Tcl_SetResult ( interp, "No filenames given", TCL_VOLATILE );
      return TCL_ERROR;
    }
  if ( a < objc-1 )
    {
      Tcl_WrongNumArgs ( interp, 3, objv, "?options? fileList" );
      return TCL_ERROR;
    }
  if ( Tcl_ListObjGetElements ( interp, objv[a], &filec, &filev ) != TCL_OK )
    return TCL_ERROR;
  a=0;
  for ( i=0; i < filec; i++ , counter++)
    {
      if (have_stop && stop)
        break;
      if (have_counter)
        Tcl_UpdateLinkedVar(interp, cvar);
      char *inp=NULL;
      inp=Tcl_GetString ( filev[i] );
      /*	sprintf(inp, "file nativename %s", inp);
      	if (Tcl_EvalEx(interp, inp, -1, TCL_EVAL_DIRECT) == TCL_ERROR)
      	{
      	  return TCL_ERROR;
      	}
      	inp=Tcl_GetString(Tcl_GetObjResult(interp));*/

      //if (inp[1] == "~")
      if ( ( smpPtr = asspFOpen ( inp , AFO_READ, ( DOBJ * ) NULL ) )
           == NULL )
        {
          if (Tcl_ObjSetVar2 ( interp, errVar, NULL, filev[i],
                               TCL_LIST_ELEMENT|TCL_APPEND_VALUE|TCL_NAMESPACE_ONLY|TCL_LEAVE_ERR_MSG) == NULL)
            return TCL_ERROR;

          buf=Tcl_NewStringObj(getAsspMsg ( asspMsgNum ), -1);
          if (Tcl_ObjSetVar2 ( interp, errVar, NULL, buf,
                               TCL_LIST_ELEMENT|TCL_APPEND_VALUE|TCL_NAMESPACE_ONLY|TCL_LEAVE_ERR_MSG ) == NULL)
            return TCL_ERROR;
          continue;
        }
      if ( ( outPtr = computeRMS ( smpPtr, opts, ( DOBJ* ) NULL ) ) == NULL )
        {
          if (Tcl_ObjSetVar2 ( interp, errVar, NULL, filev[i],
                               TCL_LIST_ELEMENT|TCL_APPEND_VALUE|TCL_NAMESPACE_ONLY|TCL_LEAVE_ERR_MSG) == NULL)
            return TCL_ERROR;

          buf=Tcl_NewStringObj(getAsspMsg ( asspMsgNum ), -1);
          if (Tcl_ObjSetVar2 ( interp, errVar, NULL, buf,
                               TCL_LIST_ELEMENT|TCL_APPEND_VALUE|TCL_NAMESPACE_ONLY|TCL_LEAVE_ERR_MSG ) == NULL)
            return TCL_ERROR;
          //continue;
          asspFClose ( smpPtr, AFC_FREE );
          continue;
        }
      if ( !flush )
        {
          Tcl_DStringInit ( &outPath );
          Tcl_SplitPath(smpPtr->filePath, &argc, &argv);
          pathv[1]=mybasename((char *)argv[argc-1]);
          Tcl_JoinPath ( 2,pathv,&outPath );
          Tcl_DStringAppend ( &outPath,".",-1 );
          Tcl_DStringAppend ( &outPath, ext,-1 );
          Tcl_Free((char *) argv);
          outPtr->filePath=Tcl_DStringValue ( &outPath );
          if ( ( outPtr=asspFOpen ( outPtr->filePath, AFO_WRITE, outPtr ) ) == NULL )
            {
              if (Tcl_ObjSetVar2 ( interp, errVar, NULL, filev[i],
                                   TCL_LIST_ELEMENT|TCL_APPEND_VALUE|TCL_NAMESPACE_ONLY|TCL_LEAVE_ERR_MSG) == NULL)
                return TCL_ERROR;
              buf=Tcl_NewStringObj(getAsspMsg ( asspMsgNum ), -1);
              if (Tcl_ObjSetVar2 (interp, errVar, NULL, buf,
                                  TCL_LIST_ELEMENT|TCL_APPEND_VALUE|TCL_LEAVE_ERR_MSG)==NULL)
                return TCL_ERROR;
              asspFClose ( smpPtr, AFC_FREE );
              asspFClose ( outPtr, AFC_FREE );
              continue;
            }
          if ( asspFFlush ( outPtr, 0 ) ==-1 )
            {
              if (Tcl_ObjSetVar2 ( interp, errVar, NULL, filev[i],
                                   TCL_LIST_ELEMENT|TCL_APPEND_VALUE|TCL_NAMESPACE_ONLY|TCL_LEAVE_ERR_MSG) == NULL)
                return TCL_ERROR;
              buf=Tcl_NewStringObj ( getAsspMsg ( asspMsgNum ), -1 );
              if (Tcl_ObjSetVar2 (interp, errVar, NULL, buf,
                                  TCL_LIST_ELEMENT|TCL_APPEND_VALUE|TCL_LEAVE_ERR_MSG)==NULL)
                return TCL_ERROR;
            }
        }
      asspFClose ( outPtr, AFC_FREE );
      asspFClose ( smpPtr, AFC_FREE );
      Tcl_DStringFree ( &outPath );
      a++;

    }
  if (have_counter)
    Tcl_UnlinkVar(interp, cvar);
  if (have_stop)
    Tcl_UnlinkVar(interp, svar);
  fflush ( stdout );
  //Tcl_FreeResult(interp);
  Tcl_SetObjResult ( interp,Tcl_NewIntObj ( a ) );
  return TCL_OK;
}


