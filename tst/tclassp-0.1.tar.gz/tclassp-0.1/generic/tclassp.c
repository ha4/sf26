/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
 /* $Id: tclassp.c,v 1.8 2008/04/29 08:06:28 lasselasse Exp $ */

#include <tcl.h>
#include <assp.h>
#include "tclassp.h"
const char *windows[] =
{
  "rectangle", "triangle", "cos", "hanning", "cos_3", "cos_4",
  "hamming", "blackman", "black_x", "black_3", "black_m3",
  "black_4", "black_M4", "gauss2_5", "gauss3_0", "gauss3_5",
  "kaiser2_0", "kaiser2_5", "kaiser3_0", "kaiser3_5", NULL
};

int winfuncs_List   (
  ClientData clientData,	/* Not used. */
  Tcl_Interp *interp  ,		/* Current interpreter */
  int objc,			/* Number of arguments */
  Tcl_Obj *const objv[]	/* Argument strings */
)
{
  int i=1;
  const char *win = windows[0];
  Tcl_Obj *outListPtr, *elem;
  outListPtr=Tcl_NewListObj(0,NULL);
  while (win != NULL)
    {
      elem = Tcl_NewStringObj(win,-1);
      if (Tcl_ListObjAppendElement(interp, outListPtr, elem) != TCL_OK)
        return TCL_ERROR;
      i++;
      win = windows[i];
    }
  Tcl_SetObjResult(interp, outListPtr);
  return TCL_OK;
}

EXTERN int	Tclassp_Init ( Tcl_Interp * interp )
{
  if ( Tcl_InitStubs ( interp, "8.1", 0 ) == NULL )
    {
      return TCL_ERROR;
    }
  if ( Tcl_PkgRequire ( interp, "Tcl", "8.1", 0 ) == NULL )
    {
      return TCL_ERROR;
    }
  if ( Tcl_PkgProvide ( interp, PACKAGE_NAME, PACKAGE_VERSION ) != TCL_OK )
    {
      return TCL_ERROR;
    }
  Tcl_CreateObjCommand ( interp, "::tclassp::acfana",
                         ( Tcl_ObjCmdProc * ) acfana_Cmd,
                         ( ClientData ) NULL, ( Tcl_CmdDeleteProc * ) NULL );
  Tcl_CreateObjCommand ( interp, "::tclassp::mhspitch",
			 ( Tcl_ObjCmdProc * ) mhspitch_Cmd,
			   ( ClientData ) NULL, ( Tcl_CmdDeleteProc * ) NULL );
  Tcl_CreateObjCommand ( interp, "::tclassp::rmsana",
                         ( Tcl_ObjCmdProc * ) rmsana_Cmd,
                         ( ClientData ) NULL, ( Tcl_CmdDeleteProc * ) NULL );
  Tcl_CreateObjCommand ( interp, "::tclassp::zcrana",
                         ( Tcl_ObjCmdProc * ) zcrana_Cmd,
                         ( ClientData ) NULL, ( Tcl_CmdDeleteProc * ) NULL );
  Tcl_CreateObjCommand ( interp, "::tclassp::winfuncs",
                         ( Tcl_ObjCmdProc * ) winfuncs_List,
                         ( ClientData ) NULL, ( Tcl_CmdDeleteProc * ) NULL );
  Tcl_CreateObjCommand ( interp, "::tclassp::ffinfo",
                         ( Tcl_ObjCmdProc * ) ffinfo_Cmd,
                         ( ClientData ) NULL, ( Tcl_CmdDeleteProc * ) NULL );
  Tcl_CreateObjCommand ( interp, "::tclassp::extract",
                         ( Tcl_ObjCmdProc * ) extract_Cmd,
                         ( ClientData ) NULL, ( Tcl_CmdDeleteProc * ) NULL );
  Tcl_SetVar ( interp, "::tclassp::errors", "", TCL_LEAVE_ERR_MSG );
  Tcl_SetVar ( interp, "::tclassp::warnings", "", TCL_LEAVE_ERR_MSG );

  return TCL_OK;
}
