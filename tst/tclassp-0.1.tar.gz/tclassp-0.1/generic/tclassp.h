/*
 * sample.h --
 *
 *	This header file contains the function declarations needed for
 *	all of the source files in this package.
 *
 * Copyright (c) 1998-1999 Scriptics Corporation.
 * Copyright (c) 2003 ActiveState Corporation.
 *
 * See the file "license.terms" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 */

#ifndef _TCLASSP
#define _TCLASSP


#include <tcl.h>
/*
 * Windows needs to know which symbols to export.  Unix does not.
 * BUILD_sample should be undefined for Unix.
 */

#ifdef BUILD_tclassp
#undef TCL_STORAGE_CLASS
#define TCL_STORAGE_CLASS DLLEXPORT
#endif /* BUILD_tclassp */

/*
 * Only the _Init function is exported.
 */
int
acfana_Cmd(
  ClientData clientData,	/* Not used. */
  Tcl_Interp *interp,		/* Current interpreter */
  int objc,			/* Number of arguments */
  Tcl_Obj *const objv[]	/* Argument strings */
);
int
    mhspitch_Cmd(
	       ClientData clientData,	/* Not used. */
	Tcl_Interp *interp,		/* Current interpreter */
 int objc,			/* Number of arguments */
 Tcl_Obj *const objv[]	/* Argument strings */
	      );
int
rmsana_Cmd(
  ClientData clientData,	/* Not used. */
  Tcl_Interp *interp,		/* Current interpreter */
  int objc,			/* Number of arguments */
  Tcl_Obj *const objv[]	/* Argument strings */
);
int
zcrana_Cmd(
  ClientData clientData,	/* Not used. */
  Tcl_Interp *interp,		/* Current interpreter */
  int objc,			/* Number of arguments */
  Tcl_Obj *const objv[]	/* Argument strings */
);
int
ffinfo_Cmd(
  ClientData clientData,	/* Not used. */
  Tcl_Interp *interp,		/* Current interpreter */
  int objc,			/* Number of arguments */
  Tcl_Obj *const objv[]	/* Argument strings */
);
int
extract_Cmd(
  ClientData clientData,	/* Not used. */
  Tcl_Interp *interp,		/* Current interpreter */
  int objc,			/* Number of arguments */
  Tcl_Obj *const objv[]	/* Argument strings */
);

EXTERN int	Tclassp_Init(Tcl_Interp * interp);

extern const char *windows[];

#endif /* _TCLASSP */
